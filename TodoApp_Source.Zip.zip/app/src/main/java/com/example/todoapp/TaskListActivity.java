package com.example.todoapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.graphics.Paint;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class TaskListActivity extends AppCompatActivity {

    DBHelper dbHelper;
    ListView listTasks;
    TextView tvEmpty;
    Button btnAddTask, btnLogout;

    int userId;
    ArrayList<Integer> taskIds = new ArrayList<>();
    ArrayList<String> taskTitles = new ArrayList<>();
    ArrayList<Integer> taskStatuses = new ArrayList<>();
    ArrayList<String> taskNotes = new ArrayList<>();

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            finish();
            return;
        }

        dbHelper = new DBHelper(this);

        listTasks = findViewById(R.id.listTasks);
        tvEmpty = findViewById(R.id.tvEmpty);
        btnAddTask = findViewById(R.id.btnAddTask);
        btnLogout = findViewById(R.id.btnLogout);

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                new ArrayList<>()
        );

        listTasks.setAdapter(adapter);

        btnAddTask.setOnClickListener(v -> showAddTaskDialog());

        listTasks.setOnItemClickListener((parent, view, position, id) -> {
            int taskId = taskIds.get(position);
            boolean completed = taskStatuses.get(position) == 0;

            boolean updated = dbHelper.updateTaskStatus(
                    taskId, userId, completed);

            if (updated) {
                loadTasks();
            }
        });

        listTasks.setOnItemLongClickListener(
                (parent, view, position, id) -> {
                    confirmDelete(position);
                    return true;
                });

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(
                    TaskListActivity.this, MainActivity.class);
            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        loadTasks();
    }

    private void showAddTaskDialog() {
        EditText inputTitle = new EditText(this);
        inputTitle.setHint("Task name");

        EditText inputNotes = new EditText(this);
        inputNotes.setHint("Optional notes");

        android.widget.LinearLayout layout =
                new android.widget.LinearLayout(this);
        layout.setOrientation(
                android.widget.LinearLayout.VERTICAL);
        layout.setPadding(40, 10, 40, 0);
        layout.addView(inputTitle);
        layout.addView(inputNotes);

        new AlertDialog.Builder(this)
                .setTitle("Add Task")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String title = inputTitle.getText()
                            .toString().trim();
                    String notes = inputNotes.getText()
                            .toString().trim();

                    if (title.isEmpty()) {
                        Toast.makeText(this,
                                "Enter a task name",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long result = dbHelper.addTask(
                            userId, title, notes);

                    if (result != -1) {
                        loadTasks();
                        Toast.makeText(this,
                                "Task added",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this,
                                "Could not add task",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadTasks() {
        taskIds.clear();
        taskTitles.clear();
        taskStatuses.clear();
        taskNotes.clear();

        Cursor cursor = dbHelper.getTasks(userId);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String title = cursor.getString(1);
            String notes = cursor.getString(2);
            int completed = cursor.getInt(3);

            taskIds.add(id);
            taskTitles.add(title);
            taskNotes.add(notes == null ? "" : notes);
            taskStatuses.add(completed);
        }

        cursor.close();

        ArrayList<String> displayItems = new ArrayList<>();

        for (int i = 0; i < taskTitles.size(); i++) {
            String prefix = taskStatuses.get(i) == 1
                    ? "✓ " : "○ ";

            String item = prefix + taskTitles.get(i);

            if (!taskNotes.get(i).isEmpty()) {
                item += "\n" + taskNotes.get(i);
            }

            if (taskStatuses.get(i) == 1) {
                item = "✓ " + taskTitles.get(i)
                        + " (Completed)";
            }

            displayItems.add(item);
        }

        adapter.clear();
        adapter.addAll(displayItems);
        adapter.notifyDataSetChanged();

        tvEmpty.setVisibility(
                taskTitles.isEmpty() ? View.VISIBLE : View.GONE);

        listTasks.setVisibility(
                taskTitles.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void confirmDelete(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Task")
                .setMessage("Permanently delete this task?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean deleted = dbHelper.deleteTask(
                            taskIds.get(position), userId);

                    if (deleted) {
                        loadTasks();
                        Toast.makeText(this,
                                "Task deleted",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

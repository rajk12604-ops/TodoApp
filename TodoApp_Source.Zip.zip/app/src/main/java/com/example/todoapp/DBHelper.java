package com.example.todoapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "TodoApp.db";
    private static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "email TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL)");

        db.execSQL("CREATE TABLE tasks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "notes TEXT, " +
                "is_completed INTEGER DEFAULT 0, " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Database upgrades will be handled here.
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            byte[] bytes = digest.digest(
                    password.getBytes(java.nio.charset.StandardCharsets.UTF_8));

            StringBuilder result = new StringBuilder();

            for (byte b : bytes) {
                result.append(String.format("%02x", b & 0xff));
            }

            return result.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(
                    "Password hashing unavailable", e);
        }
    }

    public boolean registerUser(String name,
                                String email,
                                String password) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("email", email.trim().toLowerCase());
        values.put("password_hash", hashPassword(password));

        long result = db.insert("users", null, values);
        return result != -1;
    }

    public int loginUser(String email, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE email = ? AND password_hash = ?",
                new String[]{
                        email.trim().toLowerCase(),
                        hashPassword(password)
                });

        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        cursor.close();
        return userId;
    }

    public long addTask(int userId, String title, String notes) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("title", title);
        values.put("notes", notes);
        values.put("is_completed", 0);

        return db.insert("tasks", null, values);
    }

    public Cursor getTasks(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT id, title, notes, is_completed " +
                        "FROM tasks WHERE user_id = ? ORDER BY id DESC",
                new String[]{String.valueOf(userId)});
    }

    public boolean updateTaskStatus(int taskId,
                                    int userId,
                                    boolean completed) {

        ContentValues values = new ContentValues();
        values.put("is_completed", completed ? 1 : 0);

        int rows = getWritableDatabase().update(
                "tasks", values, "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(taskId),
                        String.valueOf(userId)
                });

        return rows > 0;
    }

    public boolean deleteTask(int taskId, int userId) {

        int rows = getWritableDatabase().delete(
                "tasks", "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(taskId),
                        String.valueOf(userId)
                });

        return rows > 0;
    }
}

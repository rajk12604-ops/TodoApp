package com.example.todoapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etLoginEmail, etLoginPassword;
    Button btnLogin;
    TextView tvGoToSignup;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etLoginEmail = findViewById(R.id.etLoginEmail);
        etLoginPassword = findViewById(R.id.etLoginPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoToSignup = findViewById(R.id.tvGoToSignup);

        dbHelper = new DBHelper(this);

        btnLogin.setOnClickListener(v -> {
            String email = etLoginEmail.getText()
                    .toString().trim();
            String password = etLoginPassword.getText()
                    .toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter email and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int userId = dbHelper.loginUser(email, password);

            if (userId != -1) {
                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                // TaskListActivity will be connected next.
                Intent intent = new Intent(
                        MainActivity.this, TaskListActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
            } else {
                Toast.makeText(this,
                        "Invalid email or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        tvGoToSignup.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this, SignupActivity.class);
            startActivity(intent);
        });
    }
}

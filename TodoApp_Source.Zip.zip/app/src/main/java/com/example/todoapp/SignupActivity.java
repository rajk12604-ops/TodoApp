package com.example.todoapp;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignupActivity extends Activity {

    private EditText etName, etEmail, etPassword;
    private Button btnRegister;
    private TextView tvGoToLogin;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etName = findViewById(R.id.etSignupName);
        etEmail = findViewById(R.id.etSignupEmail);
        etPassword = findViewById(R.id.etSignupPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvGoToLogin = findViewById(R.id.tvGoToLogin);

        dbHelper = new DBHelper(this);

        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString();

            // Check empty fields
            if (name.isEmpty() || email.isEmpty()
                    || password.isEmpty()) {
                Toast.makeText(
                        SignupActivity.this,
                        "Please fill all fields",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            // Validate email
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError("Enter a valid email");
                etEmail.requestFocus();
                return;
            }

            // Validate password
            if (password.length() < 8) {
                etPassword.setError(
                        "Password must be at least 8 characters"
                );
                etPassword.requestFocus();
                return;
            }

            // Register user
            boolean registered =
                    dbHelper.registerUser(name, email, password);

            if (registered) {
                Toast.makeText(
                        SignupActivity.this,
                        "Account created successfully!",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent = new Intent(
                        SignupActivity.this,
                        MainActivity.class
                );

                intent.setFlags(
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                );

                startActivity(intent);
                finish();

            } else {
                Toast.makeText(
                        SignupActivity.this,
                        "Registration failed. Email may already exist.",
                        Toast.LENGTH_LONG
                ).show();
            }
        });

        // Return to login screen
        tvGoToLogin.setOnClickListener(v -> finish());
    }
}
